
import React from 'react';
import { SheetIcon } from './icons/SheetIcon';

export const Header: React.FC = () => {
    return (
        <header className="bg-slate-900/70 backdrop-blur-lg border-b border-slate-700/50 sticky top-0 z-10">
            <div className="container mx-auto px-4 py-4 flex items-center gap-3">
                <SheetIcon className="h-8 w-8 text-sky-400" />
                <h1 className="text-2xl font-bold text-slate-100 tracking-tight">
                    SheetGen <span className="text-sky-400">AI</span>
                </h1>
            </div>
        </header>
    );
};
