
import React from 'react';
import { DownloadIcon } from './icons/DownloadIcon';

interface PreviewPanelProps {
    svgContent: string;
    onDownload: () => void;
    isLoading: boolean;
}

const SkeletonLoader: React.FC = () => (
    <div className="space-y-5 animate-pulse p-6">
        <div className="h-8 bg-slate-700 rounded w-1/2"></div>
        <div className="h-6 bg-slate-700 rounded w-3/4 mt-6"></div>
        <div className="h-4 bg-slate-700 rounded"></div>
        <div className="h-4 bg-slate-700 rounded w-5/6"></div>
        <div className="h-4 bg-slate-700 rounded"></div>
        <div className="h-6 bg-slate-700 rounded w-1/2 mt-8"></div>
        <div className="h-4 bg-slate-700 rounded w-5/6"></div>
        <div className="h-4 bg-slate-700 rounded"></div>
    </div>
);


export const PreviewPanel: React.FC<PreviewPanelProps> = ({ svgContent, onDownload, isLoading }) => {
    return (
        <div className="bg-slate-800/50 p-6 rounded-lg border border-slate-700 flex flex-col h-full">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold text-slate-300">Sheet Preview</h2>
                <button
                    onClick={onDownload}
                    disabled={!svgContent || isLoading}
                    className="flex items-center gap-2 bg-green-600 hover:bg-green-500 disabled:bg-slate-600 disabled:cursor-not-allowed text-white font-bold py-2 px-4 rounded-lg transition duration-300 ease-in-out"
                >
                    <DownloadIcon className="h-5 w-5" />
                    Download .svg
                </button>
            </div>
            <div className="bg-white p-4 rounded-md flex-grow overflow-auto h-96 min-h-[550px]">
                {isLoading ? (
                   <div className="flex items-center justify-center h-full text-slate-400 bg-slate-800 rounded-md">
                        <SkeletonLoader />
                   </div>
                ) : svgContent ? (
                    <div
                        className="w-full h-full"
                        dangerouslySetInnerHTML={{ __html: svgContent }}
                    />
                ) : (
                    <div className="flex items-center justify-center h-full text-slate-400">
                        <p>Your generated sheet will appear here...</p>
                    </div>
                )}
            </div>
        </div>
    );
};
