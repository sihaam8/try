
import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { InputPanel } from './components/InputPanel';
import { PreviewPanel } from './components/PreviewPanel';
import { generateSheetData, SheetData } from './services/geminiService';
import { generateSvgFromData, downloadSvg } from './services/svgService';

const defaultInformation = `Music fest report:
Thursday: The Strokes played at 8pm, 5,000 people. LCD Soundsystem at 10pm, 4,500 people.
Friday: Taylor Swift headliner 9pm, 15,000 people. Bon Iver at 7pm, 6,000.
Saturday: Kendrick Lamar 9:30pm, 12,000 people. Steve Lacy at 7:30, 8,000.
Ticket sales: 3-day pass $250, sold 8,000. Thurs single day $80, sold 1,200. Fri single day $120, sold 4,000. Sat single day $120, sold 3,500.
Food sales: Pizza stall made $15,000. Burger stand $12,500. Tacos $11,000.
Merch: T-shirts $40, sold 2,000. Hoodies $80, sold 1,000. Posters $20, sold 3,000.`;

const defaultInstructions = `Organize this into tables for schedule/attendance, ticket revenue, food sales, and merch revenue. Calculate all totals. Show me a bar chart for attendance per headliner and another for merchandise revenue breakdown.`;


const App: React.FC = () => {
    const [information, setInformation] = useState<string>(defaultInformation);
    const [instructions, setInstructions] = useState<string>(defaultInstructions);
    const [generatedSvg, setGeneratedSvg] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    const handleGenerate = useCallback(async () => {
        if (!information) {
            setError('Please provide some information to process.');
            return;
        }
        if (!instructions) {
            setError('Please provide instructions on how to process the information.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setGeneratedSvg('');
        try {
            const fullPrompt = `
# USER PROVIDED INFORMATION:
---
${information}
---

# USER INSTRUCTIONS:
---
${instructions}
---
`;
            const sheetData = await generateSheetData(fullPrompt);
            const svg = generateSvgFromData(sheetData);
            setGeneratedSvg(svg);
        } catch (e) {
            const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
            setError(`Failed to generate sheet: ${errorMessage}`);
            console.error(e);
        } finally {
            setIsLoading(false);
        }
    }, [information, instructions]);

    const handleDownload = useCallback(() => {
        if (!generatedSvg) return;
        try {
            downloadSvg(generatedSvg, 'sheet.svg');
        } catch (e) {
            const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred.';
            setError(`Failed to create SVG file: ${errorMessage}`);
            console.error(e);
        }
    }, [generatedSvg]);

    return (
        <div className="min-h-screen bg-slate-900 text-slate-200 font-sans">
            <Header />
            <main className="container mx-auto px-4 py-8">
                {error && (
                    <div className="bg-red-500/20 border border-red-500 text-red-300 px-4 py-3 rounded-lg relative mb-6" role="alert">
                        <strong className="font-bold">Error: </strong>
                        <span className="block sm:inline">{error}</span>
                        <span className="absolute top-0 bottom-0 right-0 px-4 py-3" onClick={() => setError(null)}>
                            <svg className="fill-current h-6 w-6 text-red-400" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><title>Close</title><path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/></svg>
                        </span>
                    </div>
                )}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <InputPanel
                        information={information}
                        setInformation={setInformation}
                        instructions={instructions}
                        setInstructions={setInstructions}
                        onGenerate={handleGenerate}
                        isLoading={isLoading}
                    />
                    <PreviewPanel
                        svgContent={generatedSvg}
                        onDownload={handleDownload}
                        isLoading={isLoading}
                    />
                </div>
            </main>
        </div>
    );
};

export default App;
