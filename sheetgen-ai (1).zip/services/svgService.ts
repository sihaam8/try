
import saveAs from 'file-saver';
import { SheetData, Table, Chart } from './geminiService';

// --- SVG Generation Constants ---
const SVG_WIDTH = 800;
const PADDING = 20;
const HEADER_FILL = '#e2e8f0'; // slate-200
const BORDER_COLOR = '#94a3b8'; // slate-400
const FONT_COLOR = '#1e293b'; // slate-800
const FONT_FAMILY = 'Inter, sans-serif';
const FONT_SIZE = 12;
const ROW_HEIGHT = 28;
const HEADER_HEIGHT = 32;
const SECTION_GAP = 40;
const TITLE_FONT_SIZE = 18;
const CHART_HEIGHT = 250;
const HIGHLIGHT_GREEN = '#dcfce7'; // green-100
const HIGHLIGHT_RED = '#fee2e2'; // red-100
const COLOR_PALETTE = ['#38bdf8', '#fb923c', '#4ade80', '#a78bfa', '#f472b6']; // sky, orange, green, violet, pink

// --- Helper Functions ---
function escapeXml(unsafe: string): string {
    return unsafe.replace(/[<>&'"]/g, (c: string) => {
        switch (c) {
            case '<': return '&lt;';
            case '>': return '&gt;';
            case '&': return '&amp;';
            case '\'': return '&apos;';
            case '"': return '&quot;';
            default: return c;
        }
    });
}

function renderTable(table: Table, yOffset: number): { svg: string; height: number } {
    const colCount = table.headers.length;
    if (colCount === 0) return { svg: '', height: 0 };
    const colWidth = (SVG_WIDTH - 2 * PADDING) / colCount;
    let svg = '';
    
    // Find min/max values for conditional formatting
    let numbers: number[] = [];
    table.rows.forEach(row => {
        row.forEach(cell => {
            if (typeof cell === 'number' && !isNaN(cell)) {
                numbers.push(cell);
            }
        });
    });
    const minValue = numbers.length > 0 ? Math.min(...numbers) : null;
    const maxValue = numbers.length > 0 ? Math.max(...numbers) : null;

    // Table Title
    svg += `<text x="${PADDING}" y="${yOffset}" font-family="${FONT_FAMILY}" font-size="${TITLE_FONT_SIZE}" font-weight="600" fill="${FONT_COLOR}">${escapeXml(table.title)}</text>`;
    let currentY = yOffset + TITLE_FONT_SIZE + 15;

    // Header
    svg += `<rect x="${PADDING}" y="${currentY}" width="${SVG_WIDTH - 2 * PADDING}" height="${HEADER_HEIGHT}" fill="${HEADER_FILL}" />`;
    table.headers.forEach((header, i) => {
        svg += `<text x="${PADDING + i * colWidth + colWidth / 2}" y="${currentY + HEADER_HEIGHT / 2}" font-family="${FONT_FAMILY}" font-size="${FONT_SIZE}" font-weight="600" fill="${FONT_COLOR}" text-anchor="middle" dominant-baseline="middle">${escapeXml(header)}</text>`;
    });
    currentY += HEADER_HEIGHT;

    // Rows
    table.rows.forEach((row) => {
        row.forEach((cell, i) => {
            const cellValue = cell ?? '';
            let fill = '#ffffff';
            if (typeof cellValue === 'number') {
                if (cellValue === maxValue) fill = HIGHLIGHT_GREEN;
                if (cellValue === minValue) fill = HIGHLIGHT_RED;
            }
            const isTotal = table.headers[i]?.toLowerCase().includes('total') || String(row[0]).toLowerCase().includes('total');
            const fontWeight = isTotal ? '600' : '400';

            svg += `<rect x="${PADDING + i * colWidth}" y="${currentY}" width="${colWidth}" height="${ROW_HEIGHT}" fill="${fill}" stroke="${BORDER_COLOR}" stroke-width="0.5" />`;
            svg += `<text x="${PADDING + i * colWidth + 10}" y="${currentY + ROW_HEIGHT / 2}" font-family="${FONT_FAMILY}" font-size="${FONT_SIZE}" fill="${FONT_COLOR}" dominant-baseline="middle" font-weight="${fontWeight}">${escapeXml(String(cellValue))}</text>`;
        });
        currentY += ROW_HEIGHT;
    });

    return { svg, height: currentY - yOffset };
}

function renderBarChart(chart: Chart, yOffset: number): { svg: string; height: number } {
    let svg = '';
     // Chart Title
    svg += `<text x="${PADDING}" y="${yOffset}" font-family="${FONT_FAMILY}" font-size="${TITLE_FONT_SIZE}" font-weight="600" fill="${FONT_COLOR}">${escapeXml(chart.title)}</text>`;
    let currentY = yOffset + TITLE_FONT_SIZE + 25;
    
    const chartAreaWidth = SVG_WIDTH - 2 * PADDING - 40; // Space for Y-axis labels
    const chartAreaHeight = CHART_HEIGHT - 40; // Space for X-axis labels
    const chartX = PADDING + 40;
    const chartY = currentY;

    const allData = chart.datasets.flatMap(ds => ds.data);
    const maxValue = Math.max(...allData, 0);
    const scale = maxValue > 0 ? chartAreaHeight / maxValue : 0;

    // Y-axis
    svg += `<line x1="${chartX}" y1="${chartY}" x2="${chartX}" y2="${chartY + chartAreaHeight}" stroke="${BORDER_COLOR}" stroke-width="1" />`;
    for (let i = 0; i <= 5; i++) {
        const value = (maxValue / 5) * i;
        const y = chartY + chartAreaHeight - (value * scale);
        svg += `<text x="${chartX - 8}" y="${y}" text-anchor="end" dominant-baseline="middle" font-size="10" fill="${FONT_COLOR}">${Math.round(value)}</text>`;
        svg += `<line x1="${chartX - 4}" y1="${y}" x2="${chartX}" y2="${y}" stroke="${BORDER_COLOR}" stroke-width="0.5" />`;
    }

    // X-axis
    svg += `<line x1="${chartX}" y1="${chartY + chartAreaHeight}" x2="${chartX + chartAreaWidth}" y2="${chartY + chartAreaHeight}" stroke="${BORDER_COLOR}" stroke-width="1" />`;

    // Bars
    const barWidth = chartAreaWidth / (chart.labels.length * 1.5);
    chart.labels.forEach((label, i) => {
        const x = chartX + (chartAreaWidth / chart.labels.length) * (i + 0.5) - barWidth / 2;
        const barHeight = chart.datasets[0].data[i] * scale;
        svg += `<rect x="${x}" y="${chartY + chartAreaHeight - barHeight}" width="${barWidth}" height="${barHeight}" fill="${COLOR_PALETTE[i % COLOR_PALETTE.length]}" />`;
        svg += `<text x="${x + barWidth / 2}" y="${chartY + chartAreaHeight + 15}" text-anchor="middle" font-size="10" fill="${FONT_COLOR}">${escapeXml(label)}</text>`;
    });
    
    currentY += CHART_HEIGHT;
    return { svg, height: currentY - yOffset };
}

// --- Main Export Functions ---
export function generateSvgFromData(sheetData: SheetData): string {
    let svgContent = '';
    let currentY = PADDING;

    sheetData.sections.forEach((section) => {
        if (section.type === 'table') {
            const { svg, height } = renderTable(section.data, currentY);
            svgContent += svg;
            currentY += height + SECTION_GAP;
        } else if (section.type === 'chart' && section.data.type === 'bar') {
            const { svg, height } = renderBarChart(section.data, currentY);
            svgContent += svg;
            currentY += height + SECTION_GAP;
        }
    });

    const totalHeight = currentY;
    return `<svg width="${SVG_WIDTH}" height="${totalHeight}" viewBox="0 0 ${SVG_WIDTH} ${totalHeight}" xmlns="http://www.w3.org/2000/svg" style="background-color: white; border: 1px solid ${BORDER_COLOR}; border-radius: 8px;">${svgContent}</svg>`;
}

export function downloadSvg(svgString: string, fileName: string): void {
    if (!svgString) {
        throw new Error("No SVG content to download.");
    }
    const blob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
    saveAs(blob, fileName);
}
