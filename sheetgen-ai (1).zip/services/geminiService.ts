
import { GoogleGenAI, Type } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    console.warn("API_KEY environment variable not set. Gemini API calls will fail.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

// Define interfaces for the expected data structure
export interface Chart {
    title: string;
    type: 'bar' | 'line' | 'pie';
    labels: string[];
    datasets: {
        label: string;
        data: number[];
    }[];
}

export interface Table {
    title: string;
    headers: string[];
    rows: (string | number)[][];
}

export interface SheetData {
    sections: (
        | { type: 'table'; data: Table }
        | { type: 'chart'; data: Chart }
    )[];
}

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        sections: {
            type: Type.ARRAY,
            description: "An array of sections. Each section is either a table or a chart.",
            items: {
                type: Type.OBJECT,
                properties: {
                    type: {
                        type: Type.STRING,
                        enum: ['table', 'chart'],
                        description: "The type of content in this section.",
                    },
                    data: {
                        type: Type.OBJECT,
                        description: "The data for the table or chart. The properties inside this object depend on the 'type' field.",
                        properties: {
                            title: {
                                type: Type.STRING,
                                description: "A descriptive title for the table or chart."
                            },
                            // Properties for 'table' type
                            headers: {
                                type: Type.ARRAY,
                                description: "An array of strings for table column headers. Required for type 'table'.",
                                items: { type: Type.STRING }
                            },
                            rows: {
                                type: Type.ARRAY,
                                description: "An array of rows, where each row is an array of cells (string or number). Required for type 'table'.",
                                items: { type: Type.ARRAY, items: {} }
                            },
                            // Properties for 'chart' type
                            chartType: {
                                type: Type.STRING,
                                enum: ['bar', 'line', 'pie'],
                                description: "The type of chart. Required for type 'chart'."
                            },
                            labels: {
                                type: Type.ARRAY,
                                description: "An array of strings for the chart's labels (e.g., X-axis). Required for type 'chart'.",
                                items: { type: Type.STRING }
                            },
                            datasets: {
                                type: Type.ARRAY,
                                description: "An array of data sets for the chart. Required for type 'chart'.",
                                items: {
                                    type: Type.OBJECT,
                                    properties: {
                                        label: { type: Type.STRING, description: "The label for this dataset." },
                                        data: { type: Type.ARRAY, items: { type: Type.NUMBER }, description: "The numerical data points for this dataset." },
                                    },
                                    required: ['label', 'data']
                                },
                            },
                        },
                        required: ['title']
                    },
                },
                required: ['type', 'data']
            },
        },
    },
    required: ['sections']
};


export const generateSheetData = async (prompt: string): Promise<SheetData> => {
    const model = 'gemini-2.5-flash';
    
    const systemInstruction = `You are an expert data analyst and spreadsheet generator. Your task is to take messy, unstructured, human-written text and convert it into a structured JSON format suitable for generating a professional spreadsheet with tables and charts.

The user will provide the data in a section called 'USER PROVIDED INFORMATION' and instructions on how to process it in a section called 'USER INSTRUCTIONS'. You must follow these instructions carefully.

- **Parse Input:** Analyze the 'USER PROVIDED INFORMATION' section based on the 'USER INSTRUCTIONS'.
- **Organize Data:** For each category requested, create a table. Rows should represent items (people, products), and columns represent attributes (dates, prices, quantities). Preserve original numbers and text accurately.
- **Perform Calculations:** As instructed, for numerical tables, you MUST calculate row totals and column totals. If quantities and prices are present, calculate revenue. Clearly label all calculated values (e.g., 'Total', 'Average').
- **Suggest Charts:** Based on the instructions, suggest relevant charts (bar, line, pie) to visualize the information.
- **Format Output:** Your entire output must be a single JSON object that strictly adheres to the provided schema. Do not include any conversational text, explanations, or markdown. Just the JSON. Convert all numerical data points and calculations to actual numbers, not strings. When creating a section of type 'table', you must include 'headers' and 'rows' properties in its 'data' object. When creating a section of type 'chart', you must include 'chartType', 'labels', and 'datasets' in its 'data' object.
- **Data Integrity:** Ensure numbers are not swapped or missing. Charts must accurately reflect the data.
`;

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                systemInstruction: systemInstruction,
                responseMimeType: "application/json",
                responseSchema: responseSchema,
            },
        });
        
        const jsonText = response.text.trim();
        // The Gemini API sometimes returns the JSON wrapped in markdown ```json ... ```
        const cleanedJsonText = jsonText.replace(/^```json\s*|```$/g, '');
        const parsedData = JSON.parse(cleanedJsonText);
        
        if (!parsedData || !Array.isArray(parsedData.sections)) {
            console.error("Invalid data structure received from API:", parsedData);
            throw new Error("AI returned data in an unexpected format.");
        }
        
        // Transform and validate the parsed data to match our internal SheetData interface
        const transformedData: SheetData = {
            sections: parsedData.sections.map((section: any) => {
                if (!section || !section.data) {
                    console.warn("Skipping malformed section without data property:", section);
                    return null;
                }

                if (section.type === 'table') {
                    if (
                        typeof section.data.title !== 'string' ||
                        !Array.isArray(section.data.headers) ||
                        !Array.isArray(section.data.rows)
                    ) {
                        console.warn("Skipping malformed table section with missing properties:", section);
                        return null;
                    }
                    return {
                        type: 'table',
                        data: {
                            title: section.data.title,
                            headers: section.data.headers,
                            rows: section.data.rows,
                        },
                    };
                } else if (section.type === 'chart') {
                    const chartType = section.data.chartType;
                    if (
                        typeof section.data.title !== 'string' ||
                        typeof chartType !== 'string' ||
                        !['bar', 'line', 'pie'].includes(chartType) ||
                        !Array.isArray(section.data.labels) ||
                        !Array.isArray(section.data.datasets)
                    ) {
                        console.warn("Skipping malformed chart section with missing or invalid properties:", section);
                        return null;
                    }
                    return {
                        type: 'chart',
                        data: {
                            title: section.data.title,
                            type: chartType as 'bar' | 'line' | 'pie',
                            labels: section.data.labels,
                            datasets: section.data.datasets,
                        },
                    };
                }
                console.warn(`Skipping section with unknown type: "${section.type}"`, section);
                return null;
            }).filter((s: any): s is { type: 'table'; data: Table } | { type: 'chart'; data: Chart } => s !== null),
        };
        
        if (transformedData.sections.length === 0) {
             throw new Error("The AI failed to generate any valid content from the prompt. Please try rephrasing your request.");
        }

        return transformedData;

    } catch (error) {
        console.error("Error generating or parsing content from Gemini API:", error);
        if (error instanceof Error && error.message.includes('API key')) {
             throw new Error("The API key is not valid. Please check your environment configuration.");
        }
        // Use the error message if it's one of our specific validation errors
        if (error instanceof Error && (error.message.includes('unexpected format') || error.message.includes('valid content'))) {
            throw error;
        }
        throw new Error("The AI service failed to generate a valid response. The prompt might be too complex or ambiguous.");
    }
};
